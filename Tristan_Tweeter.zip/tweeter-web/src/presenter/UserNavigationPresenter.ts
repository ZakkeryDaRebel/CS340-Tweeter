import { User, AuthToken } from "tweeter-shared";
import { UserService } from "../model.service/UserService";
import { Presenter, View } from "./Presenter";

export interface UserNavigationView extends View {
  navigate: (url: string) => void;
}

export class UserNavigationPresenter extends Presenter<UserNavigationView> {
  private userService: UserService;

  public constructor(view: UserNavigationView) {
    super(view);
    this.userService = new UserService();
  }

  public async navigateToUser(
    event: React.MouseEvent,
    displayedUser: User | null,
    authToken: AuthToken | null,
    setDisplayedUser: (user: User) => void
  ): Promise<void> {
    //event.preventDefault();
    await this.doFailureReportingOperation(async () => {
      const featureURL = this.extractFeatureURL(event.target.toString());
      const alias = this.extractAlias(event.target.toString());

      const toUser = await this.userService.getUser(authToken!, alias);

      if (toUser) {
        if (!toUser.equals(displayedUser!)) {
          setDisplayedUser(toUser);
          this.view.navigate(`${featureURL}/${toUser.alias}`);
        }
      }
    }, "get user");
  }

  extractAlias = (value: string): string => {
    const index = value.indexOf("@");
    return value.substring(index);
  };

  extractFeatureURL = (value: string): string => {
    const at_index = value.indexOf("@");
    const slash_index = value.lastIndexOf("/");
    if (at_index === -1) {
      return value.substring(slash_index);
    }
    const removedAlias = value.substring(0, at_index - 1);
    const next_slash = removedAlias.lastIndexOf("/");
    return removedAlias.substring(next_slash);
  };
}
